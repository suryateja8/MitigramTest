package config;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ScreenshotHelper;


public class TestConfig {

    private WebDriver driver;

    @Before
    public void setUp() {
        // Setup Chrome WebDriver
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @After
    public void tearDown() {
        // Quit WebDriver after each scenario
        if (driver != null) {
            driver.quit();
        }
    }
    
    @BeforeStep
    public void beforeStep() {
        //takeScreenshot for example;
    	//ScreenshotHelper.takeScreenshot(driver);
    }
    
    @AfterStep
    public void afterStep() {
        //takeScreenshot for example;
    	ScreenshotHelper.takeScreenshot(driver);

    }

    public WebDriver getDriver() {
        return driver;
    }
}
