package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import config.TestConfig;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import pages.CareerPage;
import io.cucumber.java.en.Then;

public class CareersStepDefinitions {
	
	 private static final Logger logger = LoggerFactory.getLogger(CareersStepDefinitions.class);
	    private final WebDriver driver;
	    private CareerPage CareerPage;
	    
	    public CareersStepDefinitions(TestConfig testConfig) {
	        this.driver = testConfig.getDriver();
	        this.CareerPage = new CareerPage(driver);
	    }
	

    @Given("User is on the Mitigram portal homepage")
    public void user_is_on_the_mitigram_portal_homepage() throws InterruptedException {
        // Implementation to navigate to the homepage
    	logger.info("Navigating to the Mitigram portal Home page...");
    	driver.navigate().to("https://mitigram.com");
    	Thread.sleep(5000); // added just to see if the page is loaded during test run
    	logger.info("Page navigation completed."); 
    	
    }

    @When("User clicks on the Careers link")
    public void user_clicks_on_the_careers_link() {
        // Implementation to click on the Careers link
    	CareerPage.clickCareersLink();
    	logger.info("User clicked on Career link."); 
    }

    @Then("User should be redirected to the Careers page")
    public void user_should_be_redirected_to_the_careers_page() {
        // Implementation to verify redirection to the Careers page
    }
    
    @Given("User is on the Careers page")
    public void user_is_on_the_careers_page() throws InterruptedException {
        // Write code here that turns the phrase above into concrete actions
    	driver.navigate().to("https://mitigram.com/careers");
    	Thread.sleep(5000); // added just to see if the page is loaded during test run
    	logger.info("Page navigation completed."); 

    }

    @When("User clicks on the Open Positions button")
    public void user_clicks_on_the_open_positions_button() {
        // Write code here that turns the phrase above into concrete actions
    	CareerPage.clickCareersLink();
    	logger.info("User clicked on Career link."); 
    }

    @Then("User should see list of all open Positions")
    public void user_should_see_list_of_all_open_positions() {
        // Write code here that turns the phrase above into concrete actions
        
    }

    @When("User clicks on a relavent job listing")
    public void user_clicks_on_a_relavent_job_listing() {
    	// Implementation to click on a job listing
    	CareerPage.clickQApositionLink();
    	logger.info("User clicked on QA position link."); 
    }

    @When("User clicks on a Learn More Button under the listing")
    public void user_clicks_on_learn_more_button() {
        // Add code to click on the Learn More Button
    	CareerPage.clickLearnMoreButton();
    	logger.info("User clicked on QA position link."); 
    }
    
    @Then("User should be redirected to the job details page")
    public void user_should_be_redirected_to_the_job_details_page() {
        // Implementation to verify redirection to job details page
    }
}
