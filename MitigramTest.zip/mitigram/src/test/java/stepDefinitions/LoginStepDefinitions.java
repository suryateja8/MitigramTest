package stepDefinitions;

import org.openqa.selenium.WebDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import config.TestConfig;
import pages.LoginPage;

public class LoginStepDefinitions {
    
    private static final Logger logger = LoggerFactory.getLogger(LoginStepDefinitions.class);
    private final WebDriver driver;
    private LoginPage LoginPage;
    
    public LoginStepDefinitions(TestConfig testConfig) {
        this.driver = testConfig.getDriver();
        this.LoginPage = new LoginPage(driver);
    }
	
    @Given("User is on the Mitigram portal login page")
    public void user_is_on_the_mitigram_portal_login_page() throws InterruptedException {
        // Implementation to navigate to the login page
    	logger.info("Navigating to the Mitigram portal login page...");
    	driver.navigate().to("https://marketplace.mitigram.com/Account/Login");
    	Thread.sleep(5000); // added just to see if the page is loaded during test run
    	logger.info("Page navigation completed.");
    	
    }

    @When("User enters valid username as {string} and password as {string}")
    public void user_enters_valid_credentials(String username, String password) {
    	LoginPage.enterUsername(username);
    	LoginPage.enterPassword(password);
    	logger.info("UserName and Password are entered");
    	LoginPage.clickLoginButton();
    	logger.info("User clicked on login button");
    }

    @Then("User should be logged in successfully")
    public void user_should_be_logged_in_successfully() {
        // Implementation to verify successful login
    }

    @When("User enters invalid username and password")
    public void user_enters_invalid_username_and_password() {
        // Implementation to enter invalid credentials
    }

    @Then("User should see an error message")
    public void user_should_see_an_error_message() {
        // Implementation to verify error message
    }

    @When("User clicks on the {string} link")
    public void user_clicks_on_the_forgot_password_link(String linkText) {
        // Implementation to click on the "Forgot Password" link
    }

    @When("User enters the registered email for password reset")
    public void user_enters_the_registered_email_for_password_reset() {
        // Implementation to enter the registered email for password reset
    }

    @Then("User should receive a password reset email")
    public void user_should_receive_a_password_reset_email() {
        // Implementation to verify password reset email
    }
}
