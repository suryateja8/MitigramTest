package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CareerPage {

    private WebDriver driver;

    // Web elements
    @FindBy(xpath = "//a[contains(text(),'Careers')]") 
    private WebElement careersLink;

    @FindBy(xpath = "//a[contains(text(),'Open positions')]")
    private WebElement OpenPositionsButton;
    
    @FindBy(xpath = "//a[contains(text(),'QA Automation Engineer')]")
    private WebElement QApositionLink;
    
    @FindBy(xpath = "//a[contains(text(),'Learn more')]")
    private WebElement LearnMoreButton;

    // Constructor
    public CareerPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Methods to interact with the elements
    public void clickCareersLink() {
        careersLink.click();
    }

    public void clickOpenPositionsButton() {
    	OpenPositionsButton.click();
    }
    
    public void clickQApositionLink() {
    	QApositionLink.click();
    }
    
    public void clickLearnMoreButton() {
    	LearnMoreButton.click();
    }
    
}
