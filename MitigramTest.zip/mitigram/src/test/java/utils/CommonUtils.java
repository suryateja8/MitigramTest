package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CommonUtils {
	
	public static void waitForPageLoad(WebDriver driver) {
        // Implementation to wait for page to load
    }

    public static void scrollToElement(WebDriver driver, WebElement element) {
        // Implementation to scroll to a specific element
    }

}
