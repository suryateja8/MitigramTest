package utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotHelper {

    public static void takeScreenshot(WebDriver driver) {
        // Convert WebDriver instance to TakesScreenshot
        TakesScreenshot ts = (TakesScreenshot) driver;
        
        // Capture screenshot as File object
        File srcFile = ts.getScreenshotAs(OutputType.FILE);
        
        // Define the destination directory
        String destDir = "screenshots";
        
        // Create the directory if it doesn't exist
        File destDirectory = new File(destDir);
        if (!destDirectory.exists()) {
            destDirectory.mkdir();
        }
        
        // Define the file name with timestamp
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timeStamp = dateFormat.format(new Date());
        String fileName = "screenshot_" + timeStamp + ".png";
        
        // Define the destination file path
        String destPath = destDir + "/" + fileName;
        
        // Copy the screenshot file to the destination directory
        try {
            FileUtils.copyFile(srcFile, new File(destPath));
            System.out.println("Screenshot captured: " + destPath);
        } catch (IOException e) {
            System.out.println("Failed to capture screenshot: " + e.getMessage());
        }
    }
}
