package Runner;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import io.cucumber.junit.CucumberOptions;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class) 
@CucumberOptions(
		features="src/test/resources/features",   
		glue={"stepDefinitions","config"},
		tags = "@LowPriority", //this will execute all scenarios that are tagged as @LowPriority or that have both (@RegressionTest and @HighPriority) tags. 
		//"(@RegressionTest and @HighPriority) or @LowPriority",
		monochrome = true,
		plugin = {
                        "pretty",
                        "json:target/cucumber-report/cucumber.json",
                        "html:target/cucumber-report/cucumber.html"}
		
)
public class TestRunner {
	
	 @AfterClass
	 public static void afterClass() throws Exception {
		 // to generate Cucumber HTML reports
	generateReport("target/cucumber-report");
	 }
	
	 public static void generateReport(String ReportOutputPath) {
        Collection<File> jsonFiles = FileUtils.listFiles(new File(ReportOutputPath), new String[] {"json"}, true);
        List<String> jsonPaths = new ArrayList<>(jsonFiles.size());
        //jsonFiles.forEach(file -> jsonPaths.add(file.getAbsolutePath()));

        for(File file:jsonFiles ) {jsonPaths.add(file.getAbsolutePath());}

        Configuration config = new Configuration(new File("target"), "Test");
        ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
        reportBuilder.generateReports();
    }
	 
}
